#Library Imports
import pandas as pd
import numpy as np
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.preprocessing import StandardScaler
from xgboost import XGBClassifier
from sklearn.svm import LinearSVC
from sklearn.ensemble import BaggingClassifier
from sklearn.model_selection import GridSearchCV
import joblib
from flask import Flask, request, render_template
import reviews_to_use
# Load trained Pipeline
model = joblib.load('Reviews_Predictor.pkl')

df = pd.DataFrame()
dfs=[]
dfc=[]
# Create the app object
app = Flask(__name__)

# creating a function for data cleaning
#from custom_tokenizer_function import CustomTokenizer

# Define predict function
@app.route('/')
def home():
    return render_template('index.html')


@app.route('/predict',methods=['POST'])
def predict():
#    new_review = [str(x) for x in request.form.values()]
#     data = pd.DataFrame(new_review)
#     data.columns = ['new_review']
    url=[x for x in request.form.values()]
    #url=request.form.values()
    url=str(url) 
    df=reviews_to_use.webscrape(url)
    compl=0
    sugg=0
    i=0
    while i<len(df['Review']):
        predictions = model.predict([df['Review'][i]]) #[0]
        if predictions==0:
            compl=compl+1
            dfc.append(df['Review'][i])
            #return render_template('index.html', prediction_text='Complaint')
        else:
            sugg=sugg+1
            dfs.append(df['Review'][i])
            #return render_template('index.html', prediction_text='Suggestion')
        i=i+1
    cperc=(compl/len(df['Review']))*100
    sperc=(sugg/len(df['Review']))*100
    sentence="Product Statistics\nNo of Suggestions: "+str(sugg)+"\nNo of Complaints: "+str(compl)+"\nSuggestions Percentage: "+str(sperc)+"\nComplaints Percentage: "+str(cperc)
    sentence = sentence.split('\n')
    return render_template('index.html', prediction_text=sentence) 

@app.route('/disp',methods=['POST'])
def disp():
    #sentence="<h2>Suggestions :<h2>"+"\n"+str(dfs[disp.scounter]['Review'])+"\n"+str(dfs[disp.scounter+1]['Review'])+"\n"+str(dfs[disp.scounter+2]['Review'])+"\n"+str(dfs[disp.scounter+3]['Review'])+"\n"+str(dfs[disp.scounter+4]['Review'])+"\n<h2>Complaints :<h2>"+"\n"+str(dfc[disp.ccounter]['Review'])+"\n"+str(dfc[disp.ccounter+1]['Review'])+"\n"+str(dfc[disp.ccounter+2]['Review'])+"\n"+str(dfc[disp.ccounter+3]['Review'])+"\n"+str(dfc[disp.ccounter+4]['Review'])
    sentence="<h2>Suggestions :</h2>"+"\n1. "+str(dfs[disp.scounter])+"\n2. "+str(dfs[disp.scounter+1])+"\n3. "+str(dfs[disp.scounter+2])+"\n4. "+str(dfs[disp.scounter+3])+"\n5. "+str(dfs[disp.scounter+4])+"\n<h2>Complaints :</h2>"+"\n1. "+str(dfc[disp.ccounter])+"\n2. "+str(dfc[disp.ccounter+1])+"\n3 "+str(dfc[disp.ccounter+2])+"\n4. "+str(dfc[disp.ccounter+3])+"\n5. "+str(dfc[disp.ccounter+4])
    #sentence = sentence.split('\n')
    sentence = sentence.replace('\n', '<br>')
    disp.scounter+=5
    disp.ccounter+=5
    return render_template('index.html', reviews_text=sentence)   
disp.scounter = 0
disp.ccounter = 0

if __name__ == "__main__":
    app.run(debug=True)