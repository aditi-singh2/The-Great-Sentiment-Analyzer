#Library Imports
import pandas as pd
import numpy as np
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.preprocessing import StandardScaler
from xgboost import XGBClassifier
from sklearn.svm import LinearSVC
from sklearn.ensemble import BaggingClassifier
from sklearn.model_selection import GridSearchCV
import joblib
from flask import Flask, request, jsonify, render_template
# Load trained Pipeline
model = joblib.load('Reviews_Predictor.pkl')

# Create the app object
app = Flask(__name__)

# Define predict function
@app.route('/')

def home():
    return render_template('index.html')

@app.route('/predict',methods=['POST'])
def predict():
    new_review = [str(x) for x in request.form.values()]
    #data = pd.DataFrame(new_review)
    #data.columns = ['new_review']
    prediction = model.predict(new_review)[0]
    if prediction==0:
            return render_template('index.html', prediction_text='Complaint')
    else:
            return render_template('index.html', prediction_text='Suggestion')

if __name__ == "__main__":
  app.run(debug=True)